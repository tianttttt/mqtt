#include "stm32f10x.h"
#include "bsp_led.h"
#include "bsp_usart.h"
#include "bsp_key.h"
#include "delay.h"
#include "sys.h"
#include "oled.h"
#include "esp8266.h"
#include "onenet.h"
#include "mqttkit.h"
#include <string.h>
#include "dht11.h"
#define GPIO_Remap_SWJ_JTAGDisable ((uint32_t)0x00300200) /*!< JTAG-DP Disabled and SW-DP Enabled */
uint8_t i=0;
float Light=0;
u8 Led_Status =0;
u8 alarmFlag = 0;
u8 temperature;//�¶�
u8 humidity;//��ʪ��
/**
  * @brief  ������
  * @param  ��  
  * @retval ��
  */
char PUB_BUF[256];	
const char *devSubTopic[] = {"/mysmarthome/sub"};	
const char devPubTopic[]="/mysmarthome/pub";

	unsigned short timeCount = 0;	//���ͼ������
	unsigned char *dataPtr = NULL;	

void ESP8266_SendCmd1(char *cmd, char *res)
{
	Usart_SendString(DEBUG_USART3, (unsigned char *)cmd, strlen((const char *)cmd));
}
int main(void)
{	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO,ENABLE);//�ı�ָ���ܽŵ�ӳ��
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);  /*ʹ��SWD ����JTAG*/
	USART1_Config();
	USART3_Config();
	LED_GPIO_Config();
//	KEY_GPIO_Config();
	delay_init();	    	 //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);		 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
//	OLED_Init();			//��ʼ��OLED  
//	OLED_Clear(); 
	while(DHT11_Init()==1)
	{
		UsartPrintf(DEBUG_USART1, " DHT11 Error\r\n");
		break;
	}

	UsartPrintf(DEBUG_USART1, " Hardware init OK\r\n");
	ESP8266_Init();					//��ʼ��ESP8266
	while(OneNet_DevLink())			//����OneNET
		delay_ms(500);
	OneNet_Subscribe(devSubTopic, 1);	
	while (1)
	{
		DHT11_Read_Data(&temperature,&humidity);	//��ȡ��ʪ��ֵ	
		if(++timeCount % 40==5)
		{
			UsartPrintf(DEBUG_USART1, "�¶ȣ�%d  ʪ�ȣ�%d\r\n",temperature,humidity);

		//	timeCount=0;
		}
		if(++timeCount >= 200)	// 50000ms/25 =200 ���ͼ��5000ms								//���ͼ��5s
		{
			Led_Status=GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13);
			UsartPrintf(DEBUG_USART1, "OneNet_Publish\r\n");
			sprintf(PUB_BUF,"{\"Temp\":%d,\"Hum\":%d,\"Light\":%.1f,\"Led\":%d,\"Beep\":%d}",temperature,humidity,Light,Led_Status?0:1,alarmFlag);
			OneNet_Publish(devPubTopic, PUB_BUF);
			timeCount = 0;
			ESP8266_Clear();
		}
		
		dataPtr = ESP8266_GetIPD(3);
		if(dataPtr != NULL)
			OneNet_RevPro(dataPtr);
		delay_ms(10);
	}
}
/*********************************************END OF FILE**********************/












